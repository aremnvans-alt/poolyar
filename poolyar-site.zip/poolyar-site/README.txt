فایل‌های تصویر برنامه را داخل پوشه assets با این نام‌ها قرار دهید:
logo.png
screen-home.jpg
screen-expenses.jpg
screen-add.jpg
screen-income.jpg
screen-reports.jpg
screen-settings.jpg

سپس در index.html مقدار APK_LINK را با لینک دانلود واقعی APK عوض کنید.
